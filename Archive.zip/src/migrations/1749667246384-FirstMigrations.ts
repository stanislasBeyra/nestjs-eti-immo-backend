import { MigrationInterface, QueryRunner } from "typeorm";

export class FirstMigrations1749667246384 implements MigrationInterface {

    public async up(queryRunner: QueryRunner): Promise<void> {
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
    }

}
